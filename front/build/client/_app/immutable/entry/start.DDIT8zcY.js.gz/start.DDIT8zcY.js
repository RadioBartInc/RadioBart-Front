import{a as t}from"../chunks/entry.XM5ONYRv.js";export{t as start};
