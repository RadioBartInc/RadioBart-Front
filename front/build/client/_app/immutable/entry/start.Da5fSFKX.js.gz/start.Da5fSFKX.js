import{a as t}from"../chunks/entry.CM5afHCU.js";export{t as start};
