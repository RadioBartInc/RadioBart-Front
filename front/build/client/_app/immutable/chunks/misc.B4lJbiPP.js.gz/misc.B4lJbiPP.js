function t(r){return r>=80?"good_rating":r>=50?"regular_rating":"bad_rating"}export{t as g};
