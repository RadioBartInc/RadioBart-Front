const E=150,M=255;export{M,E as R};
